#include "AltarBIModule.h"

IMPLEMENT_GAME_MODULE(FAltarBIModule, AltarBI);

#define LOCTEXT_NAMESPACE "FAltarBIModule"

void FAltarBIModule::StartupModule()
{
	UE_LOG(LogTemp, Warning, TEXT("StartupModule() called"));
}

void FAltarBIModule::ShutdownModule()
{
	UE_LOG(LogTemp, Warning, TEXT("ShutdownModule() called"));
}

#undef LOCTEXT_NAMESPACE
